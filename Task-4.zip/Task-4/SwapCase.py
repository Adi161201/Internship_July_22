s= "Aditya.COM2 Mehrotra.com is2"
b=""
for i in range(len(s)):
    b=b + s[i].lower()

print(b)
