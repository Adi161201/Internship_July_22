s='Abcd'
print(ord(s[0]))

ord(s[0])+ 32 

print(ord(s[0]))