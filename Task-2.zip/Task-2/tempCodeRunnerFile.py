n=2

for i in range(n):
    string=[]
    string = str( input().split(' '))
    print(string)