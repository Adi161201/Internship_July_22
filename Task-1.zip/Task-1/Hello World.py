print ("Hello, World!")
